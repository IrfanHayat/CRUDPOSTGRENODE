let router = require("express").Router();
const posts = require("../controllers/post.controller.js");
  // Create a new Post
  router.post("/posts", posts.create);

  // Retrieve all posts
  router.get("/posts", posts.findAll);

  // Retrieve all published posts
  router.get("/posts/published", posts.findAllPublished);

  // Retrieve a single Post with id
  router.get("/posts/:id", posts.findOne);

  // Update a Post with id
  router.put("/posts/:id", posts.update);

  // Delete a Post with id
  router.delete("/posts/:id", posts.delete);

  // Delete all posts
  router.delete("/posts", posts.deleteAll);

module.exports=router