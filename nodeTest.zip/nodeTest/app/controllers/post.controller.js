const db = require("../models");
const Posts = db.Posts;
const Op = db.Sequelize.Op;

// Create and Save a new Post
exports.create = async (req, res) => {
  // Validate request
  try {
    let { title, description } = req.body;
    console.log(title,description)
    if (!title) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
      return;
    }
    let data = await Posts.create({
      title:title,
      description:description,
      published: req.body.published ? req.body.published : false
    })
   
    console.log(data)
    res.status(200).json(data);

  }
  catch (error) {
    res.status(500).send({
      message:
        error
    });
  }

};

// Retrieve all Posts from the database.
exports.findAll =async (req, res) => {
  try {
    let { title } = req.query;
    var condition = title ? { title: { [Op.iLike]: `%${title}%` } } : null;

    let data = await Posts.findAll({ where: condition })
    res.send(data);

  }
  catch (error) {
    res.status(500).send({
      message:
        error
    });
  }

};

// Find a single Post with an id
exports.findOne =async (req, res) => {
  try {
    let { id } = req.params;

    let data = await Posts.findByPk(id)
    if (data) {
      res.send(data);
    } else {
      res.status(404).send({
        message: `Cannot find Post with id=${id}.`
      });
    }


  }
  catch (error) {
    res.status(500).send({
      message:
        error
    });
  }
};

// Update a Post by the id in the request
exports.update =async (req, res) => {
  try {
    let { id } = req.params;

    let data = await Posts.update(req.body, {
      where: { id: id }
    })
    if (data == 1) {
      res.send({
        message: "Post was updated successfully."
      });
    } else {
      res.send({
        message: `Cannot update Post with id=${id}. Maybe Post was not found or req.body is empty!`

      })
    }
  }
  catch (error) {
    res.status(500).send({
      message:
        error
    });
  }
};

// Delete a Post with the specified id in the request
exports.delete =async (req, res) => {
  try {
    let { id } = req.params;

    let data = await   Posts.destroy({
      where: { id: id }
    })
  
    if (data == 1) {
      res.send({
        message: "Post was deleted successfully!"
      });
    } else {
      res.send({
        message: `Cannot delete Post with id=${id}. Maybe Post was not found!`
      });
    }
  }
  catch (error) {
    res.status(500).send({
      message:
        error
    });
  }
};

// Delete all Posts from the database.
exports.deleteAll = async (req, res) => {
  try {
    let data = await Posts.destroy({
      where: {},
      truncate: false
    })
  
  
    if (data) {
      res.send({
        message: `${data}Post was deleted successfully`
      });
    } else {
      res.send({
        message: `Cannot delete Post`
      });
    }
  }
  catch (error) {
    res.status(500).send({
      message:
        error
    });
  }

};

// find all published Post
exports.findAllPublished =async (req, res) => {
  
  try {
    let data = await Post.findAll({ where: { published: true } })
    if (data) {
      res.send(data); 
    } else {
      res.send({
        message: `Data not found`
      });
    }
  }
  catch (error) {
    res.status(500).send({
      message:
        error
    });
  }
  

};
