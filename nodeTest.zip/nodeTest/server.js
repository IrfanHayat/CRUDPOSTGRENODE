const express = require("express");

const cors = require("cors");
const app = express();
let PostRoutes=require("./app/routes/Post.routes")
var corsOptions =   {
    "origin": "*",
    "methods": "GET,HEAD,PUT,PATCH,POST,DELETE",
    "preflightContinue": false,
    "optionsSuccessStatus": 204
  }


app.use(cors(corsOptions));
app.use(express.json());  
app.use(express.urlencoded({ extended: true }));    

const db = require("./app/models");
db.sequelize.sync();
// // drop the table if it already exists
// db.sequelize.sync({ force: true }).then(() => {
//   console.log("Drop and re-sync db.");
// });

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to Irfan application." });
});

app.use('/api',PostRoutes);

// set port, listen for requests
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});
